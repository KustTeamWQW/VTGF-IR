class args():
    dataset_temp = " "          # 温度图像路径
    dataset_ir = " "      # 真实红外图像路径
    dataset_segtxt = ' '   # 语义分割标签txt路径
    output_deviation = ' '  # 自身辐射能量路径






